// src/pages/index.tsx

import { useEffect, useState, useRef, CSSProperties, ChangeEvent } from "react";
import Head from "next/head";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import TabPanel from "@/components/TabPanel";
import AddProductModal from "@/components/AddProductModal";
import { Product, ProductCategory } from "@/types";
import { useAuth } from "@/context/AuthContext";
import { db } from "@/utils/firebase";
import { collection, writeBatch, doc, onSnapshot } from "firebase/firestore";
import CategoryGrid from "@/components/CategoryGrid";

export default function Home() {
  const { isAuthenticated, loading, signOut } = useAuth();
  const router = useRouter();

  // 1) Firestore state
  const [productsByCategory, setProductsByCategory] = useState<
    Record<string, Product[]>
  >({});
  const [categoryMeta, setCategoryMeta] = useState<
    { name: string; imageUrl?: string }[]
  >([]);

  // 2) UI state
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState("All");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] =
    useState<ProductCategory | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 3) Listen to both collections
  useEffect(() => {
    // Categories metadata
    const catCol = collection(db, "categories");
    const unsubCat = onSnapshot(catCol, (snap) => {
      setCategoryMeta(
        snap.docs.map((d) => ({
          name: d.data().name as string,
          imageUrl: d.data().imageUrl as string | undefined,
        }))
      );
    });

    // Products grouping
    const prodCol = collection(db, "products");
    const unsubProd = onSnapshot(prodCol, (snap) => {
      const grouped: Record<string, Product[]> = {};
      snap.docs.forEach((d) => {
        const data = d.data() as Product & { category?: string };
        const cat = data.category || "Uncategorized";
        (grouped[cat] = grouped[cat] || []).push({
          id: d.id,
          category: cat,
          flavor: data.flavor,
          store: data.store,
          home: data.home,
          expiryDate: data.expiryDate,
        });
      });
      setProductsByCategory(grouped);
    });

    return () => {
      unsubCat();
      unsubProd();
    };
  }, []);

  // 4) Handlers
  const handleSignOut = () => {
    if (confirm("Confirm sign out?")) signOut();
  };
  const handleClear = () => {
    setSearchTerm("");
    setFilter("All");
    setSelectedCategory(null);
  };
  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    // … your existing JSON‐import logic …
  };

  // 5) Merge into ProductCategory[]
  const categories: ProductCategory[] = categoryMeta
    .map((meta) => ({
      name: meta.name,
      imageUrl: meta.imageUrl,
      products: productsByCategory[meta.name] || [],
    }))
    .sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { sensitivity: "base" })
    );

  // 6) Button style
  const ACTION_BTN: CSSProperties = {
    padding: "0.75rem",
    border: "none",
    borderRadius: "25px",
    cursor: "pointer",
    fontWeight: 900,
    textAlign: "center",
  };

  // 7) Auth guard
  if (loading)
    return <p style={{ textAlign: "center", padding: "2rem" }}>Loading…</p>;
  if (!isAuthenticated) {
    router.replace("/login?next=/");
    return null;
  }

  return (
    <Layout>
      <Head>
        <title>Smokers Haven Inventory</title>
      </Head>

      {/* Top Controls */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "0.5rem",
          marginBottom: "1rem",
          justifyContent: "space-between",
        }}
      >
        {/* Button Row */}
        <div className="buttonRow">
          {selectedCategory && (
            <button
              onClick={() => setSelectedCategory(null)}
              style={{ ...ACTION_BTN, background: "#718096", color: "white" }}
            >
              Back
            </button>
          )}
          <button
            onClick={() => setIsModalOpen(true)}
            style={{ ...ACTION_BTN, background: "#38a169", color: "white" }}
          >
            + Add Product
          </button>
          <button
            onClick={handleSignOut}
            style={{ ...ACTION_BTN, background: "#4a5568", color: "white" }}
          >
            Sign Out
          </button>
        </div>

        {/* Search / Filter / Clear */}
        <div className="searchRow">
          <input
            className="searchInput"
            type="text"
            placeholder={
              selectedCategory ? "Search Flavors" : "Search Vape Category"
            }
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />

          <select
            className="filterSelect"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option>All</option>
            <option>5% Nic</option>
            <option>0% Nic</option>
            <option>THC Disposables</option>
            <option>THC Cartridges</option>
            <option>Cigarettes</option>
            <option>Vape Juice</option>
          </select>

          <button className="clearButton" onClick={handleClear}>
            Clear
          </button>
        </div>

        {/* Hidden file input + modal */}
        <input
          type="file"
          accept=".json"
          ref={fileInputRef}
          style={{ display: "none" }}
          onChange={handleFileChange}
        />
        <AddProductModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
        />
      </div>

      {/* Grid vs. Details */}
      {!selectedCategory ? (
        <CategoryGrid
          categories={categories}
          search={searchTerm}
          filter={filter}
          onSelect={setSelectedCategory}
        />
      ) : (
        <TabPanel
          products={selectedCategory.products}
          searchTerm={searchTerm}
          filterOption={filter}
        />
      )}

      {/* Layout CSS */}
      <style jsx>{`
        .buttonRow {
          display: flex;
          gap: 0.5rem;
          width: 100%;
          align-items: center;
        }
        .buttonRow > button {
          flex: 1 1 auto;
        }

        .searchRow {
          display: flex;
          gap: 0.5rem;
          width: 100%;
          align-items: center;
        }

        /* desktop: equal flex */
        .searchInput,
        .filterSelect,
        .clearButton {
          flex: 1 1 auto;
          padding: 0.5rem;
          border: 1px solid #ccc;
          border-radius: 5px;
        }
        .clearButton {
          background: #e53e3e;
          color: white;
          border: none;
          cursor: pointer;
        }

        /* mobile override: 50% / 25% / 20% */
        @media (max-width: 768px) {
          .searchRow {
            /* switch to CSS grid for exact fractions */
            display: grid;
            grid-template-columns: 50% 25% 20%;
            gap: 0.5rem;
          }
          /* child elements automatically fill those grid columns */
        }
      `}</style>
    </Layout>
  );
}
